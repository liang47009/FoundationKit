#pragma once
#ifdef WIN32
#include "FoundationKit/GenericPlatformMacros.h"

#endif