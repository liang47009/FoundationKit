--functor for operator >
greater = function( _Left, _Right) return _Left > _Right end

--functor for operator <
less = function( _Left, _Right) return _Left < _Right end

--functor for operator >
greater_equal = function( _Left, _Right) return _Left >= _Right end

--functor for operator >
less_equal = function( _Left, _Right) return _Left <= _Right end
