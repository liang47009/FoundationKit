#if defined(__LP64__) && __LP64__
#include"curlbuild-64.h"
#else
#include"curlbuild-32.h"
#endif
