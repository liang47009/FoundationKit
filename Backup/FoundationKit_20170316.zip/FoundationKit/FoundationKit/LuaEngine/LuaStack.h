#pragma once

extern "C" {
#include "lua.h"
}
#include <functional>
#include <memory>
#include "LuaValue.h"
#include "FoundationKit/GenericPlatformMacros.h"

NS_FK_BEGIN

class LuaStack
{
public:
    typedef std::shared_ptr<LuaStack>    Pointer;
    static Pointer create(void);
    static Pointer attach(lua_State *L);

    virtual ~LuaStack();

    /**
     *  @brief Method used to get a pointer to the lua_State that the script module is attached to.
     *  @return A pointer to the lua_State that the script module is attached to.
     */
    lua_State* getLuaState(void) {
        return _state;
    }

    /**
    @brief Add a path to find lua files in
    @param path to be added to the Lua path
    */
    virtual void addSearchPath(const char* path);

    /**
    @brief Add lua loader, now it is used on android
    */
    virtual void addLuaLoader(lua_CFunction func);

    /**
    @brief reload script code contained in the given string.
    @param moduleFileName String object holding the filename of the script file that is to be executed
    @return 0 if the string is excuted correctly.
    @return other if the string is excuted wrongly.
    */
    virtual int reload(const char* moduleFileName);

    /**
    @brief Remove Lua function reference
    */
    virtual void removeScriptHandler(int nHandler);

    /**
    @brief Remove Lua function reference
    */
    virtual int reallocateScriptHandler(int nHandler);

    /**
    @brief Execute script code contained in the given string.
    @param codes holding the valid script code that should be executed.
    @return 0 if the string is excuted correctly.
    @return other if the string is excuted wrongly.
    */
    virtual int executeString(const char* codes);

    /**
    @brief Execute a script file.
    @param filename String object holding the filename of the script file that is to be executed
    */
    virtual int executeScriptFile(const char* filename);

    /**
    @brief Execute a scripted global function.
    @brief The function should not take any parameters and should return an integer.
    @param functionName String object holding the name of the function, in the global script environment, that is to be executed.
    @return The integer value returned from the script function.
    */
    virtual int executeGlobalFunction(const char* functionName);
    virtual int executeGlobalFunction(const char* functionName, const LuaValueArray& valueArray);

    virtual void clean(void);
    virtual void pushInt(int intValue);
    virtual void pushFloat(float floatValue);
    virtual void pushLong(long longValue);
    virtual void pushBoolean(bool boolValue);
    virtual void pushString(const char* stringValue);
    virtual void pushString(const char* stringValue, int length);
    virtual void pushNil(void);
    virtual void pushLuaValue(const LuaValue& value);
    virtual void pushLuaValueDict(const LuaValueDict& dict);
    virtual void pushLuaValueArray(const LuaValueArray& valueArray);
    virtual bool pushFunctionByHandler(int nHandler);

    virtual int executeFunction(int numArgs);

    virtual int executeFunctionByHandler(int nHandler, int numArgs);
    virtual int executeFunction(int handler, int numArgs, int numResults, const std::function<void(lua_State*, int)>& func);

    virtual bool handleAssert(const char *msg);

    virtual void setXXTEAKeyAndSign(const char *key, int keyLen, const char *sign, int signLen);
    virtual void cleanupXXTEAKeyAndSign();

    int luaLoadBuffer(lua_State *L, const char *chunk, int chunkSize, const char *chunkName);

protected:
    LuaStack(void)
        : _state(nullptr)
        , _callFromLua(0)
        , _xxteaEnabled(false)
        , _xxteaKey(nullptr)
        , _xxteaKeyLen(0)
        , _xxteaSign(nullptr)
        , _xxteaSignLen(0)
    {
    }

    bool init(void);
    bool initWithLuaState(lua_State *L);

    lua_State *_state;
    int _callFromLua;
    bool  _xxteaEnabled;
    char* _xxteaKey;
    int   _xxteaKeyLen;
    char* _xxteaSign;
    int   _xxteaSignLen;
};

NS_FK_END
