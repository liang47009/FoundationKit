/****************************************************************************
Copyright (c) 2015 libo.

losemymind.libo@gmail.com

****************************************************************************/
#include "Platform.h"
NS_FK_BEGIN

Platform::Platform()
{

}

Platform::~Platform()
{

}


NS_FK_END
