
#include "MessageQueue.h"

MessageQueue::MessageQueue()
{

}
