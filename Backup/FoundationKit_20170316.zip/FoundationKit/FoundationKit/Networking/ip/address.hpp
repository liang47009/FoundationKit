#ifndef LOSEMYMIND_ADDRESS_HPP
#define LOSEMYMIND_ADDRESS_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)


#include <string>
#include <iosfwd>
#include "FoundationKit/GenericPlatformMacros.h"
#include "FoundationKit/Base/error_code.hpp"
#include "FoundationKit/Networking/ip/address_v4.hpp"
#include "FoundationKit/Networking/ip/address_v6.hpp"
#include "FoundationKit/Networking/ip/bad_address_cast.hpp"
NS_FK_BEGIN
namespace network{
namespace ip{

/**
 * Implements version-independent IP addresses.
 * The ip::address class provides the ability to use either IP
 * version 4 or version 6 addresses.
 *
 * @par Thread Safety
 * @e Distinct @e objects: Safe.@n
 * @e Shared @e objects: Unsafe.
 */
class address
{
public:
    /// Default constructor.
    NETWORK_DECL address();

    /// Construct an address from an IPv4 address.
    NETWORK_DECL address(const ip::address_v4& ipv4_address);

    /// Construct an address from an IPv6 address.
    NETWORK_DECL address(const ip::address_v6& ipv6_address);

    /// Copy constructor.
    NETWORK_DECL address(const address& other);

    /// Move constructor.
    NETWORK_DECL address(address&& other);

    /// Assign from another address.
    NETWORK_DECL address& operator=(const address& other);

    /// Move-assign from another address.
    NETWORK_DECL address& operator=(address&& other);

    /// Assign from an IPv4 address.
    NETWORK_DECL address& operator=(const ip::address_v4& ipv4_address);

    /// Assign from an IPv6 address.
    NETWORK_DECL address& operator=(const ip::address_v6& ipv6_address);

    /// Get whether the address is an IP version 4 address.
    bool is_v4() const
    {
        return type_ == ipv4;
    }

    /// Get whether the address is an IP version 6 address.
    bool is_v6() const
    {
        return type_ == ipv6;
    }

    /// Get the address as an IP version 4 address.
    NETWORK_DECL ip::address_v4 to_v4() const;

    /// Get the address as an IP version 6 address.
    NETWORK_DECL ip::address_v6 to_v6() const;

    /// Get the address as a string.
    NETWORK_DECL std::string to_string() const;

    /// (Deprecated: Use other overload.) Get the address as a string.
    NETWORK_DECL std::string to_string(std::error_code& ec) const;

    /// (Deprecated: Use make_address().) Create an address from an IPv4 address
    /// string in dotted decimal form, or from an IPv6 address in hexadecimal
    /// notation.
    NETWORK_DECL static address from_string(const char* str);

    /// (Deprecated: Use make_address().) Create an address from an IPv4 address
    /// string in dotted decimal form, or from an IPv6 address in hexadecimal
    /// notation.
    NETWORK_DECL static address from_string(const char* str, std::error_code& ec);

    /// (Deprecated: Use make_address().) Create an address from an IPv4 address
    /// string in dotted decimal form, or from an IPv6 address in hexadecimal
    /// notation.
    NETWORK_DECL static address from_string(const std::string& str);

    /// (Deprecated: Use make_address().) Create an address from an IPv4 address
    /// string in dotted decimal form, or from an IPv6 address in hexadecimal
    /// notation.
    NETWORK_DECL static address from_string(const std::string& str, std::error_code& ec);

    /// Determine whether the address is a loopback address.
    NETWORK_DECL bool is_loopback() const;

    /// Determine whether the address is unspecified.
    NETWORK_DECL bool is_unspecified() const;

    /// Determine whether the address is a multicast address.
    NETWORK_DECL bool is_multicast() const;

    /// Compare two addresses for equality.
    NETWORK_DECL friend bool operator==(const address& a1, const address& a2);

    /// Compare two addresses for inequality.
    friend bool operator!=(const address& a1, const address& a2)
    {
        return !(a1 == a2);
    }

    /// Compare addresses for ordering.
    NETWORK_DECL friend bool operator<(const address& a1, const address& a2);

    /// Compare addresses for ordering.
    friend bool operator>(const address& a1, const address& a2)
    {
        return a2 < a1;
    }

    /// Compare addresses for ordering.
    friend bool operator<=(const address& a1, const address& a2)
    {
        return !(a2 < a1);
    }

    /// Compare addresses for ordering.
    friend bool operator>=(const address& a1, const address& a2)
    {
        return !(a1 < a2);
    }

private:
    // The type of the address.
    enum { ipv4, ipv6 } type_;

    // The underlying IPv4 address.
    ip::address_v4 ipv4_address_;

    // The underlying IPv6 address.
    ip::address_v6 ipv6_address_;
};

/**
 * Create an address from an IPv4 address string in dotted decimal form,
 * or from an IPv6 address in hexadecimal notation.
 * @relates address
 */
NETWORK_DECL address make_address(const char* str);

/**
 * Create an address from an IPv4 address string in dotted decimal form,
 * or from an IPv6 address in hexadecimal notation.
 * @relates address
 */
NETWORK_DECL address make_address(const char* str, std::error_code& ec);

/**
 * Create an address from an IPv4 address string in dotted decimal form,
 * or from an IPv6 address in hexadecimal notation.
 * @relates address
 */
NETWORK_DECL address make_address(const std::string& str);

/**
 * Create an address from an IPv4 address string in dotted decimal form,
 * or from an IPv6 address in hexadecimal notation.
 * @relates address
 */
NETWORK_DECL address make_address(const std::string& str, std::error_code& ec);

/**
 * Output an address as a string.
 * Used to output a human-readable string for a specified address.
 *
 * @param os The output stream to which the string will be written.
 *
 * @param addr The address to be written.
 *
 * @return The output stream.
 *
 * @relates ip::address
 */
template <typename Elem, typename Traits>
std::basic_ostream<Elem, Traits>& operator<<(std::basic_ostream<Elem, Traits>& os, const address& addr);

} // namespace ip
} // namespace network
NS_FK_END

#include "FoundationKit/Networking/ip/impl/address.hpp"
#include "FoundationKit/Networking/ip/impl/address.ipp"

#endif // LOSEMYMIND_ADDRESS_HPP



