#ifndef __NETWORKIMPL_WIN32_H__
#define __NETWORKIMPL_WIN32_H__

#include "../../../interface/INet.h"

namespace M_Engine
{
    class CNetIOS : public INet
    {
    public:
        // 向某个地址发起连接请求，请求成功发送返回true
        // 否则返回false
        bool connectTo( const char * ip , U32 port );

        // 断开当前连接
        void disconnect();

        // 发送一段数据, 数据网络层要自己拷贝， 这个函数调用过后，
        // 这段内存可能会被销毁
        void sendData( unsigned char * pData, int nBytes );

        // 当请求的连接成功建立时，产生的回调
        void onConnected() {}

        // 当请求的连接失败时，产生的回调
        void onConnectFailed() {}

        // 连接断开后产生的回调，不管是自己主动断开
        // 还是服务端主动断开，都要回调
        void onDisconnect() {}

        // 当收到数据的时候，产生的回调，
        // 回调过后，网络层自己效果pData这个内存
        // 逻辑层会自己拷贝一份来使用
        void onDataRecved( unsigned char * pData, int nBytes );
    };
};

#endif