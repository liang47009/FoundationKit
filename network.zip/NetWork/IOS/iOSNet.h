//--------------------------------------------------------------------
// 文件名:           iOSNet.h
// 内容:             iOS网络层实现头文件定义
// 说明:             
// 创建日期:         2011-5-26 14:01:00
// 创建人:           戴其蓬
// 版权所有:         苏州蜗牛电子有限公司
//--------------------------------------------------------------------


#import <Foundation/Foundation.h>
#import	<sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>
#import	<unistd.h>
#include "../../../interface/INet.h"
#include "../../../interface/ITickAble.h"
#include "../../../interface/IInitShutDown.h"
#include "../../../util/CStream.h"

namespace M_Engine
{
class iOSNet : public INet,public ITickable, public IInitShutDown
{
private:
    CFSocketRef             _socket;
	BOOL                    isConnected;
    static INet*            _instance;
    U32                     _nSerial;
    RefPtr<CStream>         _refStream;
private:
    iOSNet();
    virtual ~iOSNet();
    
    void readStream();
    static void TCPServerConnectCallBack(CFSocketRef socket, CFSocketCallBackType type, CFDataRef address, const void *data, void *info);
    
public:
    static INet * GetInstance();
    static void DestoryInstance();
    
    // 向某个地址发起连接请求，请求成功发送返回true
    // 否则返回false
    bool connectTo( const char * ip , U32 port );
    
    // 断开当前连接
    void disconnect();
    
    // 发送一段数据, 数据网络层要自己拷贝， 这个函数调用过后，
    // 这段内存可能会被销毁
    void sendData( unsigned char * pData, int nBytes );
    

    void onTick(U32 eleapsedMS);
    //void Run();
    void onEngineInit(); 
    void onEngineShutDown(); 
    
    U32  GetSerialNum() { return _nSerial; }
    void IncSerialNum() { ++_nSerial; }
    
    
    void onConnected();
    
    void onConnectFailed();
    
    void onDisconnect();
    
    void onDataRecved( unsigned char * pData, int nBytes );
    
    void setIsConnected( bool bValue );
    bool getIsConnected();
    
    bool IsConnected();

};
};