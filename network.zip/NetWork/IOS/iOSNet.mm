//--------------------------------------------------------------------
// 文件名:           iOSNet.mm
// 内容:            iOS网络层实现文件
// 说明:             
// 创建日期:         2011-5-26 14:01:00
// 创建人:           戴其蓬
// 版权所有:         苏州蜗牛电子有限公司
//--------------------------------------------------------------------

//

#import "iOSNet.h"
#include "../../../interface/ILog.h"
#include "../../../util/CObjectCreator.h"
#include "../../Events/CEventsMgr.h"
#include <fcntl.h>


namespace M_Engine
{
    INet * INet::GetNetInterface()
    {
        return iOSNet::GetInstance();
    }
    
    void INet::DestroyNetInterface(  )
    {
        iOSNet::DestoryInstance();
    }
    
    M_Engine::INet* iOSNet::_instance = NULL;
    
    const unsigned char TERMINALCHAR = 0xEE;

    iOSNet::iOSNet():_socket(nil)
                    ,isConnected(FALSE)
                    ,_nSerial(0)
    {
        _refStream = dynamic_cast<CStream*>(CObjectCreator::CreateObject("CStream").getPointer()) ;
    }

    iOSNet::~iOSNet()
    {
        disconnect();
    }


    // 创建一个INet的实例
    M_Engine::INet * iOSNet::GetInstance() 
    { 
        static iOSNet theNetInstance;
        return &theNetInstance;
    }

    // 销毁一个INet的实例
    void iOSNet::DestoryInstance() 
    {

    }

    void iOSNet::readStream()
    {
        if ( !isConnected )
            return;
        
        if( !CFSocketIsValid(_socket))
        {
            isConnected = false;
            this->onDisconnect();
            return;
        }
        
        char buffer[255];
        int len = 0;

        while ((len = recv(CFSocketGetNative(_socket), buffer, sizeof(buffer), 0)) > 0) 
        {
            //logprintf("iOSNet::receiveData Len: %d" , len);
            this->onDataRecved((unsigned char*)buffer, len);
            memset(buffer, 0, 255);
        }
        
        if (len == 0) 
        {
            isConnected = false;
            this->onDisconnect();
        }
    }

    void iOSNet::TCPServerConnectCallBack(CFSocketRef socket, CFSocketCallBackType type, CFDataRef address, const void *data, void *info)
    {
        
        iOSNet *delegate = (iOSNet *) info;
        if (data != nil) {
            //connect failed
            delegate->onConnectFailed();
            return;
        }
        int flags = fcntl(CFSocketGetNative(socket) , F_GETFL, 0);
        fcntl(CFSocketGetNative(socket), F_SETFL, flags | O_NONBLOCK);
        delegate->setIsConnected(true);
        delegate->onConnected();
    }

    void iOSNet::setIsConnected( bool bValue )
    {
        isConnected = bValue;
    }
    bool iOSNet::getIsConnected()
    {
        return isConnected;
    }
    
    // 向某个地址发起连接请求，请求成功发送返回true
    // 否则返回false
    bool iOSNet::connectTo( const char * ip , U32 port )
    {
        if ( isConnected )
        {
            if( !CFSocketIsValid(_socket))
            {
                logprintf("connection is invalid, try to reconnect.");
                this->disconnect();
            }
            else
            {
                logprintf("connection is already done");
                this->onConnected();
                return true;
            }
        }
        

        CFSocketContext CTX = {0, GetInstance(), NULL, NULL, NULL};
        _socket = CFSocketCreate(kCFAllocatorDefault, 
                                 PF_INET, 
                                 SOCK_STREAM, 
                                 IPPROTO_TCP, 
                                 kCFSocketConnectCallBack, 
                                 TCPServerConnectCallBack, 
                                 &CTX);
        if (nil == _socket) {
            //show create socket error
            logprintf("connectTo false");

            this->onConnectFailed();
            return false;
        }
        
        
        struct sockaddr_in addr4;
        memset(&addr4, 0, sizeof(addr4));
        addr4.sin_len = sizeof(addr4);
        addr4.sin_family = AF_INET;
        addr4.sin_port = htons(port);
        addr4.sin_addr.s_addr = inet_addr(ip);
        CFDataRef address = CFDataCreate(kCFAllocatorDefault, (UInt8 *)&addr4, sizeof(addr4));
        CFSocketConnectToAddress(_socket, address, -1);
        CFRunLoopRef curRunLoop = CFRunLoopGetCurrent();
        CFRunLoopSourceRef source = CFSocketCreateRunLoopSource(kCFAllocatorDefault, _socket, 0);
        CFRunLoopAddSource(curRunLoop, source, kCFRunLoopCommonModes);
        CFRelease(source);
        CFRelease(address);

        logprintf("connectTo true");

        return true;
    }

    // 断开当前连接
    void iOSNet::disconnect()
    {
        logprintf("iOSNet::disconnect");
        close(CFSocketGetNative(_socket));
        isConnected = FALSE;
        _socket = nil;
    }

    static void makeRealPkt(unsigned char * pData, int nBytes, unsigned char * pBuffRet, int & realSize)
    {
        unsigned char * pBuff1 = pData;
        unsigned char * pBuff2 = pBuffRet;
        realSize = 0;
        for (int i = 0; i < nBytes; ++i, ++pBuff1, ++pBuff2)
        {
            *pBuff2 = *pBuff1;
            ++realSize;
            if ( *pBuff2 == TERMINALCHAR )
            {
                ++realSize;
                *++pBuff2 = 0x00;
            }
        }
        *pBuff2 = TERMINALCHAR;
        *++pBuff2 = TERMINALCHAR;
        realSize += 2;
    }

    // 发送一段数据, 数据网络层要自己拷贝， 这个函数调用过后，
    // 这段内存可能会被销毁
    void iOSNet::sendData( unsigned char * pData, int nBytes )
    {
        if(CFSocketIsValid(_socket))
        {
            logprintf("iOSNet::sendData");
            int buffAllocated = 2 * sizeof(unsigned char)*(nBytes);
            unsigned char* data = (unsigned char*)malloc(buffAllocated);
            memset(data, 0, buffAllocated);
            int realSize;
            makeRealPkt( pData, nBytes, data, realSize);
            int nRet = send(CFSocketGetNative(_socket), data, realSize, 0);
            logprintf("iOSNet::sendData return %d" , nRet);
            free(data);
            data = NULL;
        }
        else
        {
            this->disconnect();
        }
    }
    
    void iOSNet::onTick(U32 eleapsedMS)
    {
        this->readStream();  
    }
    
    void iOSNet::onEngineInit()
    {
        INet::GetNetInterface();
    }
    
    void iOSNet::onEngineShutDown()
    {
        INet::DestroyNetInterface();
    }
    
    void iOSNet::onConnected()
    {
        CEventsMgr::instance()->m_signal_connected.trigger();
    }
    
    void iOSNet::onConnectFailed()
    {
        CEventsMgr::instance()->m_signal_connectFailed.trigger();
    }
    
    void iOSNet::onDisconnect()
    {
        CEventsMgr::instance()->m_signal_connectLost.trigger();
    }
    
    void iOSNet::onDataRecved( unsigned char * pData, int nBytes )
    {
        static U32 terminalCount = 0;
        const unsigned char * pByte = pData;
        for (int i = 0; i < nBytes; ++i, ++pByte)
        {
            if ( *pByte == TERMINALCHAR )
            {
                ++terminalCount;
                if ( terminalCount == 2 )
                {
                    //logprintf("Recv A Packet End.");
                    terminalCount = 0;
                    _refStream->GetWriteStream().setBytePosition(0);
                    _refStream->ProcessAsStream();
                    _refStream->ClearAll();
                }
                continue;
            }
            else if ( *pByte == 0x00 && terminalCount == 1)
            {
                _refStream->GetWriteStream().writeByte( TERMINALCHAR );
                terminalCount = 0;
                continue;
            }
            else
            {
                terminalCount = 0;
                _refStream->GetWriteStream().writeByte( *pByte );
            }
        }
    }
    
    bool iOSNet::IsConnected()
    {
        return getIsConnected();
    }
};















