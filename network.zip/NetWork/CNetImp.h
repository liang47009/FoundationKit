#ifndef __TOF_NET_IMPL_H_
#define __TOF_NET_IMPL_H_

#include <extern/gpu/network/network.h>
#include <extern/client/debug.h>
#include <extern/global_var.h>

#include <extern/m_engine/interface/ITickAble.h>
#include <extern/m_engine/util/RefBase.h>
#include <extern/m_engine/util/CStream.h>
#include <extern/m_engine/util/CObjectCreator.h>
#include <extern/m_engine/src/Events/CEventsMgr.h>

using namespace M_Engine;
class tof_socket_t : public network::socket_t,public M_Engine::ITickable
{
private:
    const static uint8_t	NET_MESSAGE_ZERO = 0x00;
    const static uint8_t	NET_MESSAGE_END_MARK = 0xEE;

    static bool encode(const uint8_t* data,size_t bytes,stream_memory_t& stream_encoded)
    {
        stream_encoded.clear();
        uint8_t byte_data = 0;
        for (size_t i = 0; i < bytes; ++i)
        {
            byte_data = data[i];
            stream_encoded<<byte_data;
            if ( byte_data  == NET_MESSAGE_END_MARK ) //结束符之间插入0x00保证明确的包结束符
            {
                byte_data = NET_MESSAGE_ZERO;
                stream_encoded << byte_data;
            }
        }
        byte_data = NET_MESSAGE_END_MARK; //以两个0xff结尾 表示一个完整包
        stream_encoded<<byte_data;
        stream_encoded<<byte_data;
        return true;
    };
    //static int decode(const uint8_t* data, size_t bytes, stream_memory_t& stream_decoded)
    //{
    //	uint8_t byte_data = 0;
    //	size_t i = 0;
    //	for (; i < bytes; ++i)
    //	{
    //		if ( data[i] == NET_MESSAGE_END_MARK && byte_data == NET_MESSAGE_END_MARK) //一个完整包
    //		{
    //			return i+1;//完整包
    //		}
    //		else if ( data[i] == NET_MESSAGE_ZERO && byte_data == NET_MESSAGE_END_MARK) //结束符之间插入0x00保证明确的包结束符
    //		{
    //			byte_data = data[i];
    //		}
    //		else if( data[i] == NET_MESSAGE_END_MARK && ((i+1) < bytes && data[i+1] == NET_MESSAGE_END_MARK) ) 
    //		{
    //			byte_data = data[i];
    //		}
    //		else
    //		{
    //			byte_data = data[i];
    //			stream_decoded<<byte_data;
    //		}
    //	}
    //	return i+1;
    //}
public:
    tof_socket_t():m_read_stream(DEFAULT_BUFFER_SIZE),m_read_encoded_steam(DEFAULT_BUFFER_SIZE),m_write_encoded_steam(DEFAULT_BUFFER_SIZE),m_need_reconnect(false)
    {
        m_current_state = STATE_DISCONNECTED;
        m_ref_stream = dynamic_cast<CStream*>(CObjectCreator::CreateObject("CStream").getPointer()) ;

        m_read_time = 0;
    }

    //为了防止read缓冲没有得到处理而一直增长，引擎假设每次收到的都是完整包，逻辑需要验证包是否完整
    virtual void dispatch_net_packet()
    {

        m_read_time = sys::system_time();
        {
            sys::scope_lock_t scope_lock(m_read_stream_mutex);
            //缓存已经接收的数据包
            m_read_stream.write(m_read_buffer.buffer(),m_read_buffer.size());
        }
    };
    void send(const uint8_t* data, size_t bytes)
    {
        encode(data,bytes,m_write_encoded_steam);
        write(m_write_encoded_steam.buffer(),m_write_encoded_steam.size());
    }
protected://需要重入
    virtual void on_error(int error_code) {
        if (error_code == SYS_ENOTCONN)
        {
            m_need_reconnect = true;
        }
        else {
            m_need_reconnect = false;
        }
    };
protected://主线程
    virtual void on_connected() { 
		CEventsMgr::instance()->m_signal_connected.trigger();
        m_current_state = STATE_CONNECTED;
	};
public:
    void disconnect_no_trigger()
    {
        disconnect();
        m_current_state = m_state;
		{
			sys::scope_lock_t scope_lock(m_read_stream_mutex);
			m_read_stream.clear();
		}
		m_write_encoded_steam.clear();
    }
    /**
    *@brief from ITickable
    *@return
    */
    void onTick(uint32_t eleapsedMS)
    {
        


        if(m_error_code == ERROR_WHEN_CONNECT)
        {
            CEventsMgr::instance()->m_signal_connectFailed.trigger();
            m_error_code = ERROR_NONE;
            m_state = STATE_DISCONNECTED;
        }

        int state = m_state;
        if(state != m_current_state)
        {
            switch (state)
            {
            case STATE_CONNECTED:
                CEventsMgr::instance()->m_signal_connected.trigger();
                break;
            case  STATE_CONNECTING:
                break;
            case STATE_DISCONNECTED:
                CEventsMgr::instance()->m_signal_connectLost.trigger(m_need_reconnect);
                if(m_need_reconnect) {m_need_reconnect = false;};
                break;
            case STATE_READING:
                break;
            case STATE_WRITING:
                break;
            }
            m_current_state = state;
        }
   
        if(is_connected()) {
            //解读并分发数据包
            sys::scope_lock_t scope_lock(m_read_stream_mutex);
            if(m_read_stream.size() >0) {
                
                const uint8_t* data  = m_read_stream.buffer();
                size_t   bytes = m_read_stream.size();
                uint8_t byte_data = 0;
                size_t i = 0;
                for (; i < bytes; ++i)
                {
                    if ( data[i] == NET_MESSAGE_END_MARK && byte_data == NET_MESSAGE_END_MARK) //一个完整包
                    {

                        if(global::g_net_time >0 ) {
                            client::debug::trace("%s , %d time:  %4fms",__FUNCTION__,__LINE__,sys::system_time() - global::g_net_time);
                        }
                        m_ref_stream->GetWriteStream().setBytePosition(0);
                        m_ref_stream->ProcessAsStream();
                        m_ref_stream->ClearAll();
                    }
                    else if ( data[i] == NET_MESSAGE_ZERO && byte_data == NET_MESSAGE_END_MARK) //结束符之间插入0x00保证明确的包结束符
                    {
                        byte_data = data[i];
                    }
                    else if( data[i] == NET_MESSAGE_END_MARK && ((i+1) < bytes && data[i+1] == NET_MESSAGE_END_MARK) ) 
                    {
                        byte_data = data[i];
                    }
                    else
                    {
                        byte_data = data[i];
                        //stream_decoded<<byte_data;
                        m_ref_stream->GetWriteStream().writeByte( byte_data );
                    }
                }
                m_read_stream.reverse(m_read_stream.size());
            }
        }
        //if(m_read_time !=0) {
        //    m_read_time = sys::system_time() - m_read_time;
        //    client::debug::trace("%s , %d cost:  %4fms",__FUNCTION__,__LINE__,m_read_time);
        //    m_read_time = 0;
        //}

    };
protected:
    sys::mutex_t m_read_stream_mutex;
    stream_memory_t m_read_stream;       //缓存没有处理过的数据包
    stream_memory_t m_read_encoded_steam;//负责分发数据流的数据流
    stream_memory_t m_write_encoded_steam;//负责分发数据流的数据流
    RefPtr<CStream>         m_ref_stream;

    int m_current_state;
    bool m_need_reconnect;

    double m_read_time;
};

class http_post_t : public network::dialog_socket_t
{
public:
    static void post(const char* url,const char* data);
private:
    void  _do_post(std::string url,std::string post);

    http_post_t() {};
private:
    static http_post_t s_instance;
    sys::mutex_t m_mutex;
};


class http_post_with_response_t
    :public M_Engine::ITickable
{
    typedef enum {
        FLAG_INVAILD ,
        FLAG_READING ,
        FLAG_READED ,
    } READFLAG;
public:
	typedef void (*Callback_OnPostResponse)(const char * , const char *  );

    static void post(const char* url,const char* data ,Callback_OnPostResponse _callback);

	static void post(const char* url,const char* data ,const char * szResponseEvent );

    void onTick(M_Engine::U32 eleapsedMS);

private:
	void _do_request(std::string url,std::string data,Callback_OnPostResponse _callback);

    void  _do_request(std::string url,std::string data);

	http_post_with_response_t():mSock(-1),mFlag(FLAG_INVAILD),mRequestUrl(""),mResponseEvent(""),mCallback(0){};

    bool __connect(const char * url , int port);

    void __disconnect();

    void __setEvent(const char * szEvent){mResponseEvent = szEvent;};
private:

    int mSock;

    static http_post_with_response_t stcInstance;

    int mFlag;

    stream_memory_t m_read_buffer;

    std::string mResponseEvent;

	Callback_OnPostResponse mCallback;

    std::string mRequestUrl;




};

#endif //__TOF_NET_IMPL_H_
