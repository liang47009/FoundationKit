#ifndef __NETWORKIMPL_WIN32_H__
#define __NETWORKIMPL_WIN32_H__

#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include "../../../interface/INet.h"
#include "../../../interface/ITickAble.h"
#include "../../../interface/IInitShutDown.h"
#include "../../../util/CStream.h"
#include "../../../util/Mutex.h"
#include <vector>
#include <list>


using boost::asio::ip::tcp;

namespace M_Engine
{
    class CNetWin32 : public INet,public ITickable, public IInitShutDown
    {
    private:
        enum
        {
            READMSG_LEN = 1024,
        };
        enum
        {
            STATE_INVALID = 0,
            STATE_CONNECTED,
            STATE_CONNECTFAILED,
            STATE_CONNECTLOST,

            STATE_MAX
        };
        struct MsgRecved
        {
            U8 * pData;
            S32 nLen;
            MsgRecved(U8 * pBuff, S32 len) : 
             pData(pBuff), nLen(len)
             {
                 pData = new U8[len];
                 memcpy(pData, pBuff, len);
             }
             ~MsgRecved()
             {
                 if (pData)
                    delete[] pData;
             }
        };
        static boost::asio::io_service io_service;
        tcp::socket sock_;
        char readMsg[READMSG_LEN];
        RefPtr<CStream>         _refStream;
        U32                     _nSerial;
        boost::thread * t;
        CMutex m_readMutex;
        int m_state_net, m_state_logic;
        std::list<MsgRecved * > m_lstRecvedData;

       void handle_connect(const boost::system::error_code& error);
       void handle_read(const boost::system::error_code& error,size_t bytes_transferred);
       void handle_write(const boost::system::error_code& error, U8 * pBuff);
    public:
        CNetWin32();
        ~CNetWin32();
        // 向某个地址发起连接请求，请求成功发送返回true
        // 否则返回false
        bool connectTo( const char * ip , U32 port );

        // 断开当前连接
        void disconnect();

        // 发送一段数据, 数据网络层要自己拷贝， 这个函数调用过后，
        // 这段内存可能会被销毁
        void sendData( unsigned char * pData, int nBytes );

        // 当请求的连接成功建立时，产生的回调
        void onConnected();

        // 当请求的连接失败时，产生的回调
        void onConnectFailed();

        // 连接断开后产生的回调，不管是自己主动断开
        // 还是服务端主动断开，都要回调
        void onDisconnect();

        // 当收到数据的时候，产生的回调，
        // 回调过后，网络层自己效果pData这个内存
        // 逻辑层会自己拷贝一份来使用
        void onDataRecved( unsigned char * pData, int nBytes );

    U32  GetSerialNum() { return _nSerial; }
    void IncSerialNum() { ++_nSerial; }

        void onTick(U32 eleapsedMS);
        
        void onEngineInit(); 
        void onEngineShutDown(); 

        // 是否连接上服务器
        bool IsConnected() ;
    };
};

#endif