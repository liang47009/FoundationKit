#include "CNetImp.h"

#include <iostream>
#include <boost/array.hpp>
#include "../../../interface/ILog.h"
#include "../../../util/CObjectCreator.h"
#include "../../Events/CEventsMgr.h"

namespace M_Engine
{
    const unsigned char TERMINALCHAR = 0xEE;
    boost::asio::io_service CNetWin32::io_service;

    INet * INet::GetNetInterface()
    {
        static CNetWin32 theNetInstance;
        return &theNetInstance;
    }

    void INet::DestroyNetInterface(  )
    {

    }

    CNetWin32::CNetWin32():
    _nSerial(0),
        sock_(io_service),
        t(0),
        m_state_net(STATE_INVALID),
        m_state_logic(STATE_INVALID)
    {
        _refStream = dynamic_cast<CStream*>(CObjectCreator::CreateObject("CStream").getPointer()) ;
    }

    CNetWin32::~CNetWin32()
    {
        sock_.close();
        if ( t )
        {
            t->join();
            delete t;
            t = NULL;
        }
    }


    static void makeRealPkt(unsigned char * pData, int nBytes, unsigned char * pBuffRet, int & realSize)
    {
        unsigned char * pBuff1 = pData;
        unsigned char * pBuff2 = pBuffRet;
        realSize = 0;
        for (int i = 0; i < nBytes; ++i, ++pBuff1, ++pBuff2)
        {
            *pBuff2 = *pBuff1;
            ++realSize;
            if ( *pBuff2 == TERMINALCHAR )
            {
                ++realSize;
                *++pBuff2 = 0x00;
            }
        }
        *pBuff2 = TERMINALCHAR;
        *++pBuff2 = TERMINALCHAR;
        realSize += 2;
    }

    // 向某个地址发起连接请求，请求成功发送返回true
    // 否则返回false
    bool CNetWin32::connectTo( const char * ip , U32 port )
    {
        if ( t )
        {
            t->join();
            delete t;
            t = NULL;
        }
        tcp::resolver resolver(io_service);

        boost::asio::ip::address_v4 addv4 = 
            boost::asio::ip::address_v4::from_string(ip);

        boost::asio::ip::address add(addv4);
        tcp::endpoint ep(  add, port );

        sock_.open(boost::asio::ip::tcp::v4());
        sock_.async_connect(ep,
            boost::bind(&CNetWin32::handle_connect, this,
            boost::asio::placeholders::error));

        t =  new boost::thread (boost::bind(&boost::asio::io_service::run, &io_service));
        return true;
    }

    void CNetWin32::handle_connect(const boost::system::error_code& error)
    {
        if (!error)
        {
            m_state_net = STATE_CONNECTED;
            sock_.async_read_some(
                //boost::asio::async_read(
                //    sock_,
                boost::asio::buffer(readMsg, READMSG_LEN),
                //    boost::asio::transfer_at_least(1),
                boost::bind(&CNetWin32::handle_read, this,
                boost::asio::placeholders::error,
                boost::asio::placeholders::bytes_transferred));
        }
        else
        {
            m_state_net = STATE_CONNECTFAILED;
            sock_.close();
        }

    }

    void CNetWin32::handle_write(const boost::system::error_code& error, U8 * pBuff)
    {
        if (!error)
        {
            free( pBuff );
        }
        else
        {
            free( pBuff );
            m_state_net = STATE_CONNECTLOST;
            sock_.close();
        }
    }

    void CNetWin32::handle_read(const boost::system::error_code& error,size_t bytes_transferred)
    {
        if (!error)
        {
            MsgRecved * pMsg = new MsgRecved((U8*)readMsg, bytes_transferred);
            m_readMutex.lock();
            m_lstRecvedData.push_back(pMsg);
            m_readMutex.unlock();
           // onDataRecved((U8*)readMsg, bytes_transferred);
            sock_.async_read_some(
                //boost::asio::async_read(
                //    sock_,
                boost::asio::buffer(readMsg, READMSG_LEN),
                //     boost::asio::transfer_at_least(1),
                boost::bind(&CNetWin32::handle_read, this,
                boost::asio::placeholders::error,
                boost::asio::placeholders::bytes_transferred));
        }
        else
        {
            if ( STATE_CONNECTLOST != m_state_net )
            {
                m_state_net = STATE_CONNECTLOST;
                sock_.close();
            }
        }

    }

    // 断开当前连接
    void CNetWin32::disconnect()
    {
        m_state_net = STATE_CONNECTLOST;
        sock_.close();
    }

    // 发送一段数据, 数据网络层要自己拷贝， 这个函数调用过后，
    // 这段内存可能会被销毁
    void CNetWin32::sendData( unsigned char * pData, int nBytes )
    {
        int buffAllocated = 2 * sizeof(unsigned char)*(nBytes);
        unsigned char* data = (unsigned char*)malloc(buffAllocated);
        memset(data, 0, buffAllocated);
        int realSize;
        makeRealPkt( pData, nBytes, data, realSize);


        logprintf("sendData %d : ", realSize);
        boost::asio::async_write(sock_,
            boost::asio::buffer(data, realSize),
            boost::bind(&CNetWin32::handle_write, this,
            boost::asio::placeholders::error, data));

    }

    void CNetWin32::onTick(U32 eleapsedMS)
    {
        m_readMutex.lock();
        std::list<MsgRecved*>::iterator it = m_lstRecvedData.begin();
        int nLimitedPkt = 1;
        while ( it != m_lstRecvedData.end() && nLimitedPkt > 0)
        {
            -- nLimitedPkt;
            onDataRecved( (*it)->pData, (*it)->nLen );
            delete (*it);
            it = m_lstRecvedData.erase( it );
        }
        m_readMutex.unlock();

        if ( m_state_logic != m_state_net )
        {
            m_state_logic = m_state_net;
            switch( m_state_logic )
            {
            case  STATE_CONNECTED:
                onConnected();
                break;
            case STATE_CONNECTFAILED:
                onConnectFailed();
                break;
            case STATE_CONNECTLOST:
                onDisconnect();
                break;
            }
        }
    }

    void CNetWin32::onEngineInit()
    {
        INet::GetNetInterface();
    }

    void CNetWin32::onEngineShutDown()
    {
        INet::GetNetInterface()->disconnect();
        Sleep(1000);
        m_readMutex.lock();
        std::list<MsgRecved*>::iterator it = m_lstRecvedData.begin();
        while ( it != m_lstRecvedData.end() )
        {
            delete (*it);
            it = m_lstRecvedData.erase( it );
        }
        m_readMutex.unlock();
        //INet::DestroyNetInterface();
    }

    void CNetWin32::onConnected()
    {
        CEventsMgr::instance()->m_signal_connected.trigger();
    }

    void CNetWin32::onConnectFailed()
    {
        CEventsMgr::instance()->m_signal_connectFailed.trigger();
    }

    void CNetWin32::onDisconnect()
    {
        CEventsMgr::instance()->m_signal_connectLost.trigger();
    }

    // 是否连接上服务器
    bool CNetWin32::IsConnected() 
    {
        return STATE_CONNECTED == m_state_logic;
    }

    // 当收到数据的时候，产生的回调，
    // 回调过后，网络层自己效果pData这个内存
    // 逻辑层会自己拷贝一份来使用
    void CNetWin32::onDataRecved( unsigned char * pData, int nBytes )
    {
        static U32 terminalCount = 0;
        const unsigned char * pByte = pData;
        for (int i = 0; i < nBytes; ++i, ++pByte)
        {
            if ( *pByte == TERMINALCHAR )
            {
                ++terminalCount;
                if ( terminalCount == 2 )
                {
                    //logprintf("Recv A Packet : ");
                    terminalCount = 0;
                    _refStream->GetWriteStream().setBytePosition(0);
                    _refStream->ProcessAsStream();
                    _refStream->ClearAll();
                }
                continue;
            }
            else if ( *pByte == 0x00 && terminalCount == 1)
            {
                _refStream->GetWriteStream().writeByte( TERMINALCHAR );
                terminalCount = 0;
                continue;
            }
            else
            {
                terminalCount = 0;
                _refStream->GetWriteStream().writeByte( *pByte );
            }
        }
    }
};