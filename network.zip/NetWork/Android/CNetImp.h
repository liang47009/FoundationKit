
#include "../../../interface/INet.h"
#include "../../../interface/ITickAble.h"
#include "../../../interface/IInitShutDown.h"
#include "../../../util/CStream.h"
#include "../../../util/Mutex.h"
#include <vector>
#include <list>

#ifdef _WINDOWS_
	#include <WinSock.h>
#include <windows.h>
#else
	#include <sys/socket.h>
	#include <sys/types.h>
	#include <errno.h>
	#include <string.h>
	#include <netdb.h>
	#include <sys/types.h>
	#include <netinet/in.h>
	#include <fcntl.h>
	#include <pthread.h>
	#include <sys/endian.h>
	#include <arpa/inet.h>
	#include <signal.h>

#endif

namespace M_Engine
{
#ifndef _WINDOWS_
	const int INVALID_SOCKET = 0;
	const int SOCKET_ERROR = -1;
#endif
	const int MAXDATASIZE = 1024;

	struct MsgRecved
	{
		U8 * pData;
		S32 nLen;
		MsgRecved(U8 * pBuff, S32 len) : 
		pData(pBuff), nLen(len)
		{
			pData = new U8[len];
			memcpy(pData, pBuff, len);
		}
		~MsgRecved()
		{
			if (pData)
				delete[] pData;
		}
	};

	std::list<MsgRecved * > m_lstRecvedData;

	class CNetImp : public INet,public ITickable, public IInitShutDown
	{
	private:
		enum
		{
			READMSG_LEN = 1024,
		};
		enum
		{
			STATE_INVALID = 0,
			STATE_CONNECTED,
			STATE_CONNECTFAILED,
			STATE_CONNECTLOST,

			STATE_MAX
		};

		unsigned int m_cientSocket;

		char buf[MAXDATASIZE];
		struct hostent *host;
		struct sockaddr_in serv_addr;

		char readMsg[READMSG_LEN];

		RefPtr<CStream>         _refStream;
		U32                     _nSerial;

		CMutex m_readMutex;
		int m_state_net, m_state_logic;
		

		static void* handle_read(void* lpParameter);
		static void handle_write(U8 * pBuff);
	public:
		CNetImp();
		~CNetImp();

		bool connectTo( const char * ip , U32 port );
		void disconnect();
		void sendData( unsigned char * pData, int nBytes );
		void onConnected();
		void onConnectFailed();
		void onDisconnect();
		void onDataRecved( unsigned char * pData, int nBytes );

		U32  GetSerialNum() { return _nSerial; }
		void IncSerialNum() { ++_nSerial; }

		void onTick(U32 eleapsedMS);
		void onEngineInit(); 
		void onEngineShutDown(); 

		// 是否连接上服务器
		bool IsConnected() ;
	};
};