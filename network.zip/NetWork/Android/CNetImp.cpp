
#include "CNetImp.h"
#include <iostream>

#ifdef _WINDOWS_
#include <errno.h>
#else
#include <sys/errno.h>
#endif
#include "../../../interface/Ilog.h"
#include "../../../util/CObjectCreator.h"
#include "../../Events/CEventsMgr.h"
#include "ui/uidef.h"
#include "ui/Ilog.h"

namespace M_Engine
{
    const unsigned char TERMINALCHAR = 0xEE;

    INet * INet::GetNetInterface()
    {
        static CNetImp theNetInstance;
        return &theNetInstance;
    }

    void INet::DestroyNetInterface(  )
    {
	
    }

    CNetImp::CNetImp():
    _nSerial(0),
    m_state_net(STATE_INVALID),
    m_state_logic(STATE_INVALID)
    {
        _refStream = dynamic_cast<CStream*>(CObjectCreator::CreateObject("CStream").getPointer()) ;

#ifdef _WINDOWS_
		//Init Windows Socket
		WSADATA  Ws;
		if ( WSAStartup(MAKEWORD(2,2), &Ws) != 0 )
		{
			GetLog()->Trace("Init Windows Socket Failed");
			logprintf("Init Windows Socket Failed:: %d", GetLastError());
		}
#endif
    }
	
    CNetImp::~CNetImp()
    {

#if defined(_WINDOWS_)
	closesocket(m_cientSocket);
	WSACleanup();
#else
	close(m_cientSocket);
#endif

    }

    static void makeRealPkt(unsigned char * pData, int nBytes, unsigned char * pBuffRet, int & realSize)
    {
        unsigned char * pBuff1 = pData;
        unsigned char * pBuff2 = pBuffRet;
        realSize = 0;
		for (int i = 0; i < nBytes; ++i, ++pBuff1, ++pBuff2)
		{
			*pBuff2 = *pBuff1;
			++realSize;
			if ( *pBuff2 == TERMINALCHAR )
			{
				++realSize;
				*++pBuff2 = 0x00;
			}
		}
        *pBuff2 = TERMINALCHAR;
        *++pBuff2 = TERMINALCHAR;
        realSize += 2;
    }

    // Connect to server, success return true
    // otherwise return false
    bool CNetImp::connectTo( const char * ip , U32 port )
    {	
		serv_addr.sin_family=AF_INET;
		serv_addr.sin_port=htons(port);
		serv_addr.sin_addr.s_addr=inet_addr(ip);
		memset(&(serv_addr.sin_zero),0, strlen((const char*)serv_addr.sin_zero));
		
		//Create Socket
		m_cientSocket = socket(AF_INET, SOCK_STREAM, 0);
		GetLog()->Trace("Create Socket m_cientSocket: %d|%d", m_cientSocket, errno);

		if ( m_cientSocket < 0)
		{
			GetLog()->Trace("Create Socket Failed: %d", errno);
			return false;
		}

		GetLog()->Trace("Ready to connect server : %d-%s-%d", m_cientSocket, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr));
		if (connect(m_cientSocket, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) == -1) 
		{
			GetLog()->Trace("Connect server fail: %s:%d", ip, port);
			m_state_net = STATE_CONNECTFAILED;
			return false;
		}
		else
		{
			GetLog()->Trace("Connect server success: %s:%d", ip, port);
		}

		m_state_net = STATE_CONNECTED;
		
#if defined(_WINDOWS_)
		HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)handle_read, 
			(LPVOID)m_cientSocket, 0, NULL);
		if ( hThread == NULL )
		{
			logprintf("Create Thread Failed!");
		}
		
		CloseHandle(hThread);

#else
		pthread_t   thread_id;
		pthread_attr_t   attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr,   PTHREAD_CREATE_DETACHED); 
		pthread_create(&thread_id,&attr,handle_read ,&m_cientSocket);
		pthread_attr_destroy(&attr);
#endif
		
        return true;
    }

    void* CNetImp::handle_read(void* lpParameter)
    {
		int recvbytes = 0;
		char* buf = new char[MAXDATASIZE];
		memset(buf, 0x00, strlen(buf));

		CMutex readMutex;

#if defined(_WINDOWS_)
		SOCKET socket = (SOCKET)lpParameter;
#else
		int socket = (int)*(int *)lpParameter;
#endif

		while ( true )
		{
			if ((recvbytes=recv(socket, buf, MAXDATASIZE, 0)) == SOCKET_ERROR) {
#if defined(_WINDOWS_)
				int error = GetLastError();
				GetLog()->Trace("Recv msg fail");
				logprintf("Recv msg fail: %d", error);
#endif
				return (void*)0;
			}
			if (recvbytes > 0)
			{
				GetLog()->Trace("Recv msg success: %s", buf);
				readMutex.lock();
				MsgRecved * pMsg = new MsgRecved((U8*)buf, recvbytes);
				m_lstRecvedData.push_back(pMsg);
				readMutex.unlock();
			}
		}

		return (void*)1;
    }

	void CNetImp::handle_write(U8 * pBuff)
	{

	}

    // Disconnect current connection
    void CNetImp::disconnect()
    {
        m_state_net = STATE_CONNECTLOST;

#if defined(_WINDOWS_)
		closesocket(m_cientSocket);
		WSACleanup();
#else
		close(m_cientSocket);
#endif

    }

    // Send the data, network layer need copy that data
    // then the buf of data will release
    void CNetImp::sendData( unsigned char * pData, int nBytes )
    {
        int buffAllocated = 2 * sizeof(unsigned char)*(nBytes);
        unsigned char* data = (unsigned char*)malloc(buffAllocated);
        memset(data, 0, buffAllocated);
        int realSize;
        makeRealPkt( pData, nBytes, data, realSize);


		
		int Ret = send(m_cientSocket, (const char *)data, realSize, 0);

		if (Ret == -1)
		{
			GetLog()->Trace("SendData msg fail");
			 logprintf("SendData %d : ", realSize);
		}
		else
		{
			GetLog()->Trace("SendData msg success");
			 logprintf("SendData %d : ", realSize);
		}
		free( data );
    }

    void CNetImp::onTick(U32 eleapsedMS)
    {
        m_readMutex.lock();
        std::list<MsgRecved*>::iterator it = m_lstRecvedData.begin();
        while ( it != m_lstRecvedData.end() )
        {
            onDataRecved( (*it)->pData, (*it)->nLen );
            delete (*it);
            it = m_lstRecvedData.erase( it );
        }
        m_readMutex.unlock();

        if ( m_state_logic != m_state_net )
        {
            m_state_logic = m_state_net;
            switch( m_state_logic )
            {
            case  STATE_CONNECTED:
                onConnected();
                break;
            case STATE_CONNECTFAILED:
                onConnectFailed();
                break;
            case STATE_CONNECTLOST:
                onDisconnect();
                break;
            }
        }
    }

    void CNetImp::onEngineInit()
    {
        INet::GetNetInterface();
    }

    void CNetImp::onEngineShutDown()
    {
        INet::GetNetInterface()->disconnect();
    }

    void CNetImp::onConnected()
    {
        CEventsMgr::instance()->m_signal_connected.trigger();
    }

    void CNetImp::onConnectFailed()
    {
        CEventsMgr::instance()->m_signal_connectFailed.trigger();
    }

    void CNetImp::onDisconnect()
    {
        CEventsMgr::instance()->m_signal_connectLost.trigger();
    }

    //Judge the connection state
    bool CNetImp::IsConnected() 
    {
        return STATE_CONNECTED == m_state_logic;
    }

    // Callback when receive data
    // then network layer will release the buf of pData
   
	// logic layer will copy this buf to use
    
	void CNetImp::onDataRecved( unsigned char * pData, int nBytes )
    {
        static U32 terminalCount = 0;
        const unsigned char * pByte = pData;
        for (int i = 0; i < nBytes; ++i, ++pByte)
        {
            if ( *pByte == TERMINALCHAR )
            {
                ++terminalCount;
                if ( terminalCount == 2 )
                {
                    //logprintf("Recv A Packet : ");
                    terminalCount = 0;
                    _refStream->GetWriteStream().setBytePosition(0);
                    _refStream->ProcessAsStream();
                    _refStream->ClearAll();
                }
                continue;
            }
            else if ( *pByte == 0x00 && terminalCount == 1)
            {
                _refStream->GetWriteStream().writeByte( TERMINALCHAR );
                terminalCount = 0;
                continue;
            }
            else
            {
                terminalCount = 0;
                _refStream->GetWriteStream().writeByte( *pByte );
            }
        }
    }
};
