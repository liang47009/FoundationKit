
#include <extern/m_engine/interface/INet.h>
#include <extern/m_engine/interface/Ilog.h>
#include <extern/ui/asyn_work.h>
#include <extern/gpu/network/client_socket.h>
#include <UI/IEventManager.h>
#include <UI/Var.h>



namespace M_Engine
{
    namespace INet
    {
        tof_socket_t& GetNetInterface()
        {
            static tof_socket_t s_tof_net;
            return s_tof_net;
        };
    };
};


http_post_t http_post_t::s_instance;
void http_post_t::post(const char* url,const char* data)
{

    if(s_instance.is_connected())
    {
        return;
    }
    std::string host = url;
    std::string post = data;
    ui_wrap::asyn_work::push(new callback_fun_member_2_t<http_post_t,std::string,std::string>(s_instance,&http_post_t::_do_post,host,post));
};

bool __makePostCommand(const std::string& url , const std::string& post ,std::string& strHost ,int & nPort ,std::string& strCmd )
{
    int pos = url.find("/",7);
    if (pos==-1)
    {
        return false;
    }
    strHost = url.substr(7,pos-7);
    int nColonPos = strHost.find(":");
    nPort = 80;
    if(nColonPos != -1)
    {
        nPort = atoi(strHost.substr(nColonPos+1,strHost.length()).c_str());
        strHost= strHost.substr(0,nColonPos);
    }
    std::string path = url.substr(pos,url.length());
    if(post == "")
    {
        strCmd = "GET " + path + " HTTP/1.0\r\nHost:" + strHost + "\r\n\r\n" ;

    }
    else
    {
        char pLength[16] = {0} ;
        sprintf(pLength,"%d",post.length());
        strCmd = "POST " + path + " HTTP/1.0\r\nHost:" + strHost 
            +"\r\nContent-Type:application/x-www-form-urlencoded"
            +"\r\nContent-Length:" + pLength + "\r\n\r\n" + post;
    }
    return true;
}

void   http_post_t::_do_post(std::string url,std::string post) {

    int nPort = 80;
    string host(""),cmd("");
    if(!__makePostCommand(url , post , host ,nPort , cmd ))
        return;
    if(s_instance.connect((char*)host.c_str(),nPort))
    {
        s_instance.write((unsigned char*)cmd.c_str(),cmd.length());
    }
    else
    {
        M_Engine::logprintf("can not connect to data collect server!");
    }
};


http_post_with_response_t http_post_with_response_t::stcInstance;

void http_post_with_response_t::post( const char* url,const char* data,const char * szResponseEvent )
{
    std::string host(url);
    std::string post(data);
    http_post_with_response_t::stcInstance.__setEvent(szResponseEvent);
    http_post_with_response_t::stcInstance.mRequestUrl = url;
	http_post_with_response_t::stcInstance.mCallback = 0;
    ui_wrap::asyn_work::push(new callback_fun_member_2_t<http_post_with_response_t,std::string,std::string>(stcInstance,&http_post_with_response_t::_do_request,host,post));
}

void http_post_with_response_t::post( const char* url,const char* data ,Callback_OnPostResponse _callback )
{
	std::string strHost(url);
	std::string strData(data);
	ui_wrap::asyn_work::push(new callback_fun_member_3_t<http_post_with_response_t,std::string,std::string,Callback_OnPostResponse>(stcInstance,&http_post_with_response_t::_do_request,strHost,strData,_callback));

}

void http_post_with_response_t::_do_request( std::string url,std::string data )
{
    int nPort = 80;
    string host(""),cmd("");
    do 
    {
        if(!__makePostCommand(url , data , host ,nPort , cmd ))
            break;
        if(!this->__connect(host.c_str(),nPort))
        {
            mFlag = FLAG_INVAILD;
            M_Engine::logprintf("can not connect to data collect server!");
            break;
        }
        int nSizeCount = 0 ;
        do 
        {//send loop
            nSizeCount += ::send(mSock, cmd.c_str() + nSizeCount , cmd.length() - nSizeCount , 0);
        } while (nSizeCount < cmd.length());

        mFlag = FLAG_READING;
        int nRecvFlag = -1;
        auto_buffer<char> buffer(1024*2);
        m_read_buffer.clear();
        nSizeCount = 0;
        do 
        {
            nRecvFlag = ::recv(mSock , buffer.buffer(), buffer.size(), 0);
            if(nRecvFlag > 0)
                m_read_buffer.write((uint8_t*)buffer.buffer(),nRecvFlag);

        } while (nRecvFlag>0);

        if (nRecvFlag<0)
        {
            mFlag = FLAG_INVAILD;
            M_Engine::logprintf("can not recv data !");
            break;
        }
        m_read_buffer.write((uint8_t*)"\r\n",2);
        mFlag = FLAG_READED;
    } while (0);
    __disconnect();
}

void http_post_with_response_t::_do_request( std::string url,std::string data,Callback_OnPostResponse _callback )
{
	__setEvent("");
	mCallback = _callback;
	_do_request(url,data);
}

bool http_post_with_response_t::__connect( const char * url , int port )
{
    sockaddr_in conn;

    conn.sin_family = AF_INET;
    conn.sin_port = ntohs(port);
    conn.sin_addr.s_addr = INADDR_ANY;

    if(network::help::is_ip_address(url)) {
        conn.sin_addr.s_addr = inet_addr(url);
    }
    else {
        hostent * host = gethostbyname(url);
        if(!host) {
            assert(false);//host name set error
            return false;
        }
        conn.sin_addr= *((struct in_addr*)host->h_addr);
    }
    memset(&(conn.sin_zero),0, sizeof((const char*)conn.sin_zero));
    /* open socket */
    mSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    ////block mode
    u_long arg = 0;
    ::ioctlsocket(mSock, FIONBIO, &arg);

    /* try to connect */
    int result = ::connect(mSock, (const sockaddr*)&conn, sizeof(sockaddr_in));

    if(result < 0)
    {
        closesocket(mSock);
        return false;
    }
    return true;
}

void http_post_with_response_t::__disconnect()
{
    if (mSock > 0)
        closesocket(mSock);

    mSock = -1;
}

void http_post_with_response_t::onTick( M_Engine::U32 eleapsedMS )
{
    if (mFlag != FLAG_READED)
        return;

	string tmp;
	m_read_buffer>>tmp;
	m_read_buffer.clear();

	if (mCallback)
	{
		(*mCallback)(mRequestUrl.c_str(),tmp.c_str());
		mCallback = 0;
	}
	else if (!mResponseEvent.empty())
	{
		VarList vars;
		vars.Push(mRequestUrl.c_str());
		vars.Push(tmp.c_str());
		GetEventManager()->SendEvent(mResponseEvent.c_str(),vars);
		mResponseEvent.clear();
	}
	mFlag = FLAG_INVAILD;
}
