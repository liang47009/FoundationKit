#include "CStream.h"
#include "CObjectCreator.h"
#include "StringUtil.h"
#include "../interface/IProtocol.h"
#include "../interface/INet.h"
#include <vector>
#include "UI/Var.h"
#include "../src/Protocol/OuterMsg.h"

namespace M_Engine
{
    // 实现类实例的自动创建
    IMPLEMENT_GAMEOBJ(CStream);

    // 导出类到脚本


    

    void CStream::ProcessAsProtocol()
    {
        IProtocol::DispatchCustomProtocol(m_varList);
    }
    
    void CStream::ProcessAsStream()
    {
        IProtocol::DispathStreamProtocol(*this);
    }

    CStream::CStream():m_stream(1024 * 1024)
    {
    }

    CStream::~CStream()
    {}

    // 清空stream
    void CStream::ClearStream()
    {
        m_stream.clear();
        m_stream.reset();
    }
    // 清空args
    void CStream::ClearArgs()
    {
        m_varList.Clear();
    }
    // 清空stream和args
    void CStream::ClearAll()
    {
        ClearStream();
        ClearArgs();
    }

    // 从stream解析到参数列表，规定格式：16为数据类型 ＋ 数据
    void CStream::ParseStreamToArgs()
    {
        ClearArgs();

        U8 nType;

        while (
            (nType = (U8)m_stream.readByte( )) >  VTYPE_UNKNOWN &&
            nType < VTYPE_MAX && 
            m_stream.getBitSpaceAvailable() )
        {
            switch ( nType )
            {
            case VTYPE_INT:		// 32位整数
                AddInt( m_stream.readInt(  ) );
                break;
            case VTYPE_FLOAT:	// 单精度浮点数
                AddFloat( m_stream.readFloat(  ) );
                break;
            case VTYPE_STRING:	// 字符串
                m_stream.readShort();
                AddString( m_stream.readString() );
                break;
            case VTYPE_WIDESTR:	// 宽字符串
                {
                    m_stream.readShort();
                    const wchar_t * ptr = m_stream.readWString();
                    AddWStringFromWStr( ptr );
                break;
                }
            case VTYPE_OBJECT:	// 对象号
                {
                    int ident = m_stream.readInt();
                    int serial = m_stream.readInt();
                    AddObjectByInt( ident, serial );
                }
                break;
            default:
                break;
            }
        }
    }

    // 从参数列表打包到stream
    void CStream::ParseArgsToStream()
    {
        U32 nCount = m_varList.GetCount();
        U8 nType = VTYPE_UNKNOWN;
        for ( U32 i = 0 ; i < nCount ; ++i)
        {
            nType = m_varList.GetType( i );
            m_stream.writeByte( nType );
            switch( nType )
            {
            case VTYPE_INT:		// 32位整数
                m_stream.writeInt( m_varList.IntVal( i ) );
                break;
            case VTYPE_FLOAT:	// 单精度浮点数
                m_stream.writeFloat( m_varList.FloatVal( i ) );
                break;
            case VTYPE_STRING:	// 字符串
                {
                    const char * szValue = m_varList.StringVal( i );
                    short bytesLen = (strlen(szValue) + 1);
                    m_stream.writeShort(bytesLen);
                }
                m_stream.writeString( m_varList.StringVal( i ), 0 );
                break;
            case VTYPE_WIDESTR:	// 宽字符串
                {
                    const wchar_t * szValue = m_varList.WideStrVal( i );
                    short bytesLen = (wcslen(szValue) + 1) * 2;
                    m_stream.writeShort(bytesLen);
                }
                m_stream.writeWString( m_varList.WideStrVal(i), 0 );
                break;
            case VTYPE_OBJECT:	// 对象号
                m_stream.writeInt( m_varList.ObjectVal(i).nIdent );
                m_stream.writeInt( m_varList.ObjectVal(i).nSerial );
                break;
            default:
                break;
            }
        }
    }

    // 设置stream的内存，并且自己管理
    void CStream::CopyToStream( U8 * pBuff, U32 nBytes )
    {
        ClearStream();
        m_stream.setBuffer( pBuff, nBytes );
        m_stream.takeOwnership();
    }

    // 调用脚本接口处理逻辑
    void CStream::OnPacketRecved()
    {}

    // 读接口
    S32 CStream::GetType( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.GetType( idx );
    }
    bool CStream::GetBoolen( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.BoolVal( idx );
    }
    U32 CStream::GetInt( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.IntVal( idx );
    }
    U64 CStream::GetInt64( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.Int64Val( idx );
    }
    F32 CStream::GetFloat( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.FloatVal( idx );
    }
    F64 CStream::GetDouble( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.DoubleVal( idx );
    }
    const char * CStream::GetString( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.StringVal( idx );
    }
    const wchar_t * CStream::GetWString( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        return m_varList.WideStrVal( idx );
    }
    const char * CStream::GetWStringAsStr( U32 idx )
    {
        assert( m_varList.GetCount() > idx );
        static std::string str ;
#ifdef _WIN32
        str = StringUtil::WideStrAsString(m_varList.WideStrVal( idx ), CP_UTF8);
#else
        str = StringUtil::WideStrAsString(m_varList.WideStrVal( idx ), 0);
#endif
        return str.c_str();
    }
    const char * CStream::GetObject( U32 idx )
    {
		static char szID[128]={0};
        assert( m_varList.GetCount() > idx );
        PERSISTID id = m_varList.ObjectVal( idx );
        sprintf( szID, "%d.%d", id.nIdent, id.nSerial );
        return szID;
    }

    // 写接口
    void CStream::AddBoolen( bool bValue )
    {
        m_varList << bValue;
    }
    void CStream::AddInt( U32 uValue )
    {
        m_varList << uValue;
    }
    void CStream::AddInt64( U64 nValue64 )
    {
        m_varList.AddInt64(nValue64);
    }
    void CStream::AddFloat( F32 fValue )
    {
        m_varList << fValue;
    }
    void CStream::AddDouble( F64 fValue64 )
    {
        m_varList << fValue64;
    }
    void CStream::AddString( const char * szValue )
    {
        m_varList << szValue;
    }
    void AddStringFixLength( const char * szValue, U32 length )
    {
        
    }
    void CStream::AddWStringFromStr( const char * szwValue )
    {
#ifdef _WIN32
        std::wstring wStr = StringUtil::StringAsWideStr( szwValue, CP_UTF8 );
#else
        std::wstring wStr = StringUtil::StringAsWideStr( szwValue, 0 );
#endif
        m_varList << wStr.c_str();
    }
    void CStream::AddWStringFromWStr( const wchar_t * szwValue )
    {
        m_varList << (const wchar_t *)szwValue;
    }
    void CStream::AddObjectByStr( const char * obj )
    {
        PERSISTID id;
		char szTemp[128]={0};
        strcpy( szTemp, obj );
        char * pIdent = strchr( szTemp, '.' );
        *pIdent = 0;
        ++pIdent;
        id.nIdent = atoi( szTemp );
        id.nSerial = atoi( pIdent );
        m_varList << id;
    }

    void CStream::AddObjectByInt( U32 nIdent, U32 nSerial )
    {
        PERSISTID id(nIdent, nSerial);
        m_varList << id;
    }
    
    void CStream::SendCustomMsg()
    {
        ClearStream();
        // 自定义消息
        m_stream.writeShort(CLIENT_CUSTOM);
        // 16个8bit校验码
        for (int i = 0; i < 16; ++i)
        {
            m_stream.writeByte(0);
        }
        // 32bit消息序列号
		m_stream.writeInt(INet::GetSerialNum());
        INet::IncSerialNum();
        // 2个32bit，异步事件标识
        m_stream.writeInt(0);
        m_stream.writeInt(0);
        // 16bit参数数量
        m_stream.writeShort(m_varList.GetCount());
        // 将剩下的数据打包
        ParseArgsToStream();
        // 发包
        int len = m_stream.getBytePosition();
        m_stream.setBytePosition(0);
        U8* pData = (U8*)m_stream.getBytePtr();
        theNet.send(pData, len);
    }
    
    // 将CVarList读到VarList
    void CStream::ParseArgsToVarList( VarList & varList )
    {
        U32 nCount = m_varList.GetCount();
        U8 nType = VTYPE_UNKNOWN;
        for ( U32 i = 0 ; i < nCount ; ++i)
        {
            nType = m_varList.GetType( i );
            switch( nType )
            {
                case VTYPE_INT:		// 32位整数
                    varList.Push( m_varList.IntVal( i ) );
                    break;
                case VTYPE_FLOAT:	// 单精度浮点数
                    varList.Push( m_varList.FloatVal( i ) );
                    break;
                case VTYPE_STRING:	// 字符串
                    varList.Push (m_varList.StringVal( i ));
                    break;
                case VTYPE_WIDESTR:	// 宽字符串
                    varList.Push ( m_varList.WideStrVal( i ) );
                    break;
                case VTYPE_OBJECT:	// 对象号
                    {
						char szTemp[128]={0};
                        sprintf( szTemp, "%d.%d",  (int)m_varList.ObjectVal(i).nIdent, (int)m_varList.ObjectVal(i).nSerial);
                        varList.Push( szTemp );
                    }
                    break;
                default:
                    break;
            }
        }
    }
    
    // 将VarList读取到CVarList
    void CStream::ParseVarListToCVarList( const VarList & varList )
    {
        int nCount = varList.Count();
        int nType = VTYPE_UNKNOWN;
        for (int i = 0; i < nCount; i += 2)
        {
            nType = varList.GetVar(i).AsInt();
            switch ( nType )
            {
                case VTYPE_INT:		// 32位整数
                    AddInt( varList.GetVar(i + 1).AsInt() );
                    break;
                case VTYPE_FLOAT:	// 单精度浮点数
                    AddFloat( varList.GetVar(i + 1).AsFloat() );
                    break;
                case VTYPE_STRING:	// 字符串
                    AddString( varList.GetVar(i + 1).AsString() );
                    break;
                case VTYPE_WIDESTR:	// 宽字符串
                    AddWStringFromStr( varList.GetVar(i + 1).AsString() );
                    break;
                case VTYPE_OBJECT:
                    AddObjectByStr(varList.GetVar(i + 1).AsString());
                    break;
                default:
                    break;
            }
        }
    }
    
};


















