#ifndef __STREAM_H__
#define __STREAM_H__

#include "../luawraper/CScriptAble.h"
#include "BitStream.h"
#include "var/VarList.h"

class VarList;

namespace M_Engine
{
    class   CStream : public CScriptAble
    {
        BitStream m_stream;
        CVarList m_varList;
    public:
        CStream();
        ~CStream();

        // 从stream解析到参数列表
        void ParseStreamToArgs();
        // 从参数列表打包到stream
        void ParseArgsToStream();
        // 设置stream的内存，并且自己管理
        void CopyToStream( U8 * pBuff, U32 nBytes );
        
        // 将CVarList读到VarList
        void ParseArgsToVarList( VarList & varList );
        
        // 将VarList读取到CVarList
        void ParseVarListToCVarList( const VarList & varList );

        // 清空stream
        void ClearStream();
        // 清空args
        void ClearArgs();
        // 清空stream和args
        void ClearAll();

        // 调用脚本接口处理逻辑
        void OnPacketRecved();
        
        BitStream & GetWriteStream() { return m_stream; }

        // 读接口
        S32 GetType( U32 idx );
        bool GetBoolen( U32 idx );
        U32 GetInt( U32 idx );
        U64 GetInt64( U32 idx );
        F32 GetFloat( U32 idx );
        F64 GetDouble( U32 idx );
        const char * GetString( U32 idx );
        const wchar_t * GetWString( U32 idx );
        const char * GetWStringAsStr( U32 idx );
        const char * GetObject( U32 idx );

        // 写接口
        void AddBoolen( bool bValue );
        void AddInt( U32 uValue );
        void AddInt64( U64 nValue64 );
        void AddFloat( F32 fValue );
        void AddDouble( F64 fValue64 );
        void AddString( const char * szValue );
        void AddWStringFromStr( const char * szwValue );
        void AddWStringFromWStr( const wchar_t * szwValue );
        void AddObjectByStr( const char * obj );
        void AddObjectByInt( U32 nIdent, U32 nSerial );
        
        // 写一个固定长度的字符串
        void AddStringFixLength( const char * szValue, U32 length );

        // 当作一个协议执行逻辑处理
        void ProcessAsProtocol();
        void ProcessAsStream();
        
        // 当作自定义协议发送
        void SendCustomMsg();
    };
};

#endif



















