//--------------------------------------------------------------------
// 文件名:           IProtocol.cpp
// 内容:             
// 说明:             
// 创建日期:         2011-6-16 14:08:51
// 创建人:           王磊
// 版权所有:         苏州蜗牛电子有限公司
//--------------------------------------------------------------------

#include "../../interface/IProtocol.h"
#include "../../interface/Ilog.h"
#include <assert.h>

#include <extern/global_var.h>
#include <extern/client/debug.h>

#include <extern/m_engine/src/Protocol/OuterMsg.h>
namespace M_Engine
{
    static const char * szProtocols[] = 
    {
        "SERVER_SET_VERIFY",
        "SERVER_SET_ENCODE",
        "SERVER_ERROR_CODE",
        "SERVER_LOGIN_SUCCEED",
        "SERVER_WORLD_INFO",
        "SERVER_TERMINATE",
        "SERVER_ENTRY_SCENE",
        "SERVER_EXIT_SCENE",
        "SERVER_ADD_OBJECT",
        "SERVER_REMOVE_OBJECT",
        "SERVER_OBJ_VISIBLE",
        "SERVER_PROPERTY_TABLE",
        "SERVER_STATE_TABLE",
        "SERVER_RECORD_TABLE",
        "SERVER_SCENE_PROPERTY",
        "SERVER_OBJECT_PROPERTY",
        "SERVER_ACTION",
        "SERVER_SPEECH",
        "SERVER_SYSTEM_INFO",
        "SERVER_MENU",
        "SERVER_MENU_CLEAR",
        "SERVER_CUSTOM",
        "SERVER_CREATE_VIEW",
        "SERVER_DELETE_VIEW",
        "SERVER_VIEW_PROPERTY",
        "SERVER_VIEW_ADD",
        "SERVER_VIEW_REMOVE",
        "SERVER_VIEWOBJ_PROPERTY",
        "SERVER_RECORD_ADDROW",
        "SERVER_RECORD_DELROW",
        "SERVER_RECORD_GRID",
        "SERVER_RECORD_CLEAR",
        "SERVER_LOCATION",
        "SERVER_ALL_DEST",
        "SERVER_ALL_POSI",
        "SERVER_IDLE",
        "SERVER_WARNING",
        "SERVER_FROM_GM",
        "SERVER_TRACERT",
        "SERVER_WORLD_CUSTOM",

        "SERVER_UNKOWN_40",
        "SERVER_UNKOWN_41",
        "SERVER_UNKOWN_43",
        "SERVER_UNKOWN_43",
        "SERVER_UNKOWN_44",
        "SERVER_UNKOWN_45",
        "SERVER_UNKOWN_46",
        "SERVER_UNKOWN_47",
        "SERVER_UNKOWN_48",
        "SERVER_UNKOWN_49",
        "SERVER_UNKOWN_50",

        "SERVER_BACKDOOR_LOGIN",

        "SERVER_UNKOWN_52",
        "SERVER_UNKOWN_53",

        "SERVER_REP_REMOTE_CTRL",

        //index 55
        "SERVER_SVR_INFO",              //128
        "SERVER_SVR_INFO_NEW",   
        "SERVER_QUEUE",

        "SERVER_UNKOWN_131",
        "SERVER_UNKOWN_132",
        "SERVER_UNKOWN_133",
        "SERVER_UNKOWN_134",
        "SERVER_UNKOWN_135",
        "SERVER_UNKOWN_136",
        "SERVER_UNKOWN_137",
        "SERVER_UNKOWN_138",
        "SERVER_UNKOWN_139",
        "SERVER_UNKOWN_140",
        "SERVER_UNKOWN_141",
        "SERVER_UNKOWN_142",
        "SERVER_UNKOWN_143",

        "SERVER_SYSTEM_INFO_NEW", //144
        "SERVER_MENU_NEW",
        "SERVER_LOCATION_NEW",
        "SERVER_ALL_DEST_NEW",
        "SERVER_CLASS_VISPROP",
        "SERVER_VIEW_EXCHANGE"
    };
    // 协议池实例
    IProtocol::PROTOCOLS & IProtocol::GetProtoclsPool ()
    {
        static IProtocol::PROTOCOLS protocols;
        return protocols;
    }

    // 每个协议一个协议ID
    IProtocol::IProtocol( U32 idx )
    {
        assert( NULL == GetMatchedProtocol( idx ) );
        PROTOCOLS & pool = GetProtoclsPool();
        pool.insert( std::pair< U32, IProtocol* > (idx, this) );
    }

    // 根据协议ID获得协议的实例
    IProtocol * IProtocol::GetMatchedProtocol( U32 idx )
    {
        PROTOCOLS & pool = GetProtoclsPool();
        PROTOCOLS::iterator it = pool.find( idx );
        if ( it != pool.end() )
            return it->second;
        return NULL;
    }

    // 将参数集当作协议来处理
    void IProtocol::DispatchCustomProtocol ( const IVarList & params )
    {
        U32 idx = params.IntVal( 0 );
        IProtocol * pProtocol = GetMatchedProtocol( idx );
        if ( pProtocol )
        {
            logprintf("协议[%d]：处理中", idx);
            pProtocol->ProcessCustomProtocol( params );
        }
        else if ( idx != 35 )
        {
            logprintf("协议[%d]：未处理", idx);
        }
    }
    
    // 将一段数据流当作协议来处理
    void IProtocol::DispathStreamProtocol ( CStream & stream )
    {
        U16 idx = stream.GetWriteStream().readShort();
        
        if(idx == SERVER_CUSTOM) {
            if(global::g_net_time >0 ) {
                client::debug::trace("%s , %d SERVER_CUSTOM processed",__FUNCTION__,__LINE__);
            }
        }
        IProtocol * pProtocol = GetMatchedProtocol( idx );
        const char * msgName = idx < 55 ? szProtocols[idx] : szProtocols[idx - 73];
        if ( pProtocol )
        {
            // 21、22、24、28、30、31 号协议，自定义协议，不输出日志，太多了，看着烦
/*            if ( idx != 21 && idx != 22 && idx != 24 && idx != 28 && idx != 30 && idx != 31)
            {
                logprintf("%s[%d] : Processing", msgName,idx);
            } */           

            pProtocol->ProcessStreamProtocol( stream );
        }
        else if ( idx != 35 )
        {
            logprintf("%s[%d] : Not Processed", msgName,idx);
        }
    }
};