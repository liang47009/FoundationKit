/**
@file		IProtocol
@brief		协议的实现头文件
@author		王磊
@date		7/21/2011
@copyright	苏州蜗牛电子有限公司
*/
#ifndef __IPROTOCOL_H__
#define __IPROTOCOL_H__

#include "../../../platform/CCPlatformMacros.h"
#include "../util/types.h"
#include "../util/var/IVarList.h"
#include "../util/BitStream.h"
#include "../util/CStream.h"
#include <map>
/**
@addtogroup M_Engine
@{
*/

/**
@brief M_Engine 名字空间

M_Engine 名字空间
*/
namespace M_Engine
{
    /**
    @brief		实现接收服务端协议的接口 
    */
    class   IProtocol
    {
        typedef std::map< U32, IProtocol * > PROTOCOLS;
    private:
        /**
        @brief		禁止默认建构 
        */
        IProtocol() {}
        
        /**
        @brief		管理各个协议的MAP 
        */
        static PROTOCOLS & GetProtoclsPool ();
        
        /**
        @brief		根据协议ID获得协议的指针 
        */
        static IProtocol * GetMatchedProtocol( U32 idx );
    public:
        IProtocol( U32 idx );
        virtual ~IProtocol() {}

        /**
        @brief		分发原始流协议 
        */
        static void DispathStreamProtocol ( CStream & stream );
        
        /**
        @brief		分发数据集协议 
        */
        static void DispatchCustomProtocol ( const IVarList & params );

        /**
        @brief		处理数据集协议 
        */
        virtual void ProcessCustomProtocol ( const IVarList & params ) {}
        
        /**
        @brief		处理原始流协议 
        */
        virtual void ProcessStreamProtocol( CStream & stream ) {}
    };

#define IMPLEMENT_PROTOCOL(CLS,IDX) \
    CLS G_PROTOCOL_##CLS(IDX)
};
/** @} */
#endif